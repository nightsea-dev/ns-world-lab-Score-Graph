# Types – Score Graph Contracts

## Overview (`packages/types`)

This package defines the shared TypeScript contracts used across the score graph system.

It exists to:
- enforce structural consistency between server and web
- make data shapes explicit and stable
- prevent accidental coupling through ad-hoc objects


## Responsibilities

- Definition of core graph primitives (nodes, edges, scores)
- Shared DTOs used by API and UI
- Cross-package type safety and boundary enforcement

This package contains **no runtime logic**.


## Design Principles

- Types are **structural contracts**, not business logic
- No dependency on framework or runtime environment
- No side effects, no I/O, no state
- Changes are intentional and propagate explicitly to consumers

This makes the package safe to depend on from any layer.


## Score Semantics

The `score` field is defined here as a numeric value in the range `[0, 1]`.

Interpretation rules:
- `0` represents no overlap or relation
- `1` represents maximal similarity
- No thresholding or categorisation is encoded at the type level

This ensures that semantic decisions remain outside the contract layer.


## Tech Stack

- TypeScript

The workspace is orchestrated with **Turbo**.


## Diagram

Type-level dependencies and boundaries:

- [Types dependency diagram](/_docs/types.svg)


## Key Dependencies (Types)

This package has no external runtime dependencies.

## License
**MIT**