# apps/types — Shared Contracts

## Overview

Shared TypeScript contracts used across API and web.

---

## Usage

```ts
import type { GraphNode, GraphEdge } from "@ns-kb/types"
```
