# Types – Shared Contracts

## Overview (`packages/types`)

This package contains shared TypeScript types used across the system.

It ensures consistent data structures between:
- Server
- Web client

---

## Contents

- Graph node types
- Graph edge types
- Shared utility types

---

## Usage

import { GraphNode, GraphEdge } from "@ns-kb/types"

---

## Design Notes

- No runtime logic
- Types only
- Stable contracts across layers
