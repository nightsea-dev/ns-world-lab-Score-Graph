
/**
 * ---
 * NON PORTABLE
 * --
 * * must go out of this project
 * * kept in this [pgk] for the sake of DEMO
 * 
 * \@ns-sg/types
 */
export type _extract_from_types = "_extract_from_types"

export * from "./api/index.js"
export * from "./infra/index.js"
export * from "./utils/index.js"
export * from "./knowledge-graph/index.js"
