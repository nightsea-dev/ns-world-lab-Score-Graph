

export type HasShow = {
    show: boolean
}