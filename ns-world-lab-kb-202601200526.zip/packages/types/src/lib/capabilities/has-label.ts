export type HasLabel = {
    label: string
}


