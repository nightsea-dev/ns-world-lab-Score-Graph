


export type HasWidth = {
    width: number
}
