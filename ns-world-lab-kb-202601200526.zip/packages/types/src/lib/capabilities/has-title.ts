


export type HasTitle<
    T extends any = string
> = {
    title: T
}