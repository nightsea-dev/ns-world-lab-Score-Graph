

export type HasAction<
    A extends string
> = {
    action: A
}