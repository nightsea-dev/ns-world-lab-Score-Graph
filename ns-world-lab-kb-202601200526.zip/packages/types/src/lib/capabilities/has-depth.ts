export type HasDepth =
    { depth: number }
