



export type HasContent<
T extends any = string
> = {
    content: T
}