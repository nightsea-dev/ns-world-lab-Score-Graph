


export type HasHeight = {
    height: number
}