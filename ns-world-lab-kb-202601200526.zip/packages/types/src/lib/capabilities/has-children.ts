

export type HasChildren<
    T extends any
> = {
    children: T
}