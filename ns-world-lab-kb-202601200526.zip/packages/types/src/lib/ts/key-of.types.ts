
export type KeyOf<
    T extends object
> = Extract<keyof T, string>

