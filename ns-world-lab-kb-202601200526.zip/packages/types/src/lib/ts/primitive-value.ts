export type PrimitiveValue =
    | string
    | number
    | boolean
    | bigint
    | symbol
    | null
    | undefined

