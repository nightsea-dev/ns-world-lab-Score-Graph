import { graphApi } from "./apps/knowledge-graph/index.js"

graphApi.run()
