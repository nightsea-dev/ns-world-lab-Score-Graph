export * from "./is-ident.js"
