# Server – Knowledge Graph API

## Overview

This package provides the backend API for the knowledge graph system.

It is responsible for:
- Building and storing graph data
- Exposing nodes and edges via HTTP endpoints

---

## Tech Stack

- Node.js
- TypeScript
- Express or NestJS
- PostgreSQL or graph-oriented storage

---

## Responsibilities

- Graph construction logic
- Persistence layer
- API endpoints for graph retrieval

---

## Development

npm install
npm run dev

---

## API Shape (Simplified)

Nodes: id, label  
Edges: source, target, score
