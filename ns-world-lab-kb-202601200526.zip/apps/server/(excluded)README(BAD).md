# apps/server — Knowledge Graph API

## Overview

Backend API responsible for graph construction, scoring, and persistence.

---

## Running

```bash
npm install
npm run turbo:dev
```

---

## Environment Variables

```env
DATABASE_URL=postgres://USER:PASSWORD@HOST:5432/ns_world_lab
DATABASE_SCHEMA_NAME=knowledge_graph_1
```
