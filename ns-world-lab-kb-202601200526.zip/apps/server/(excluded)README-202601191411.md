# Server – Knowledge Graph API

## Overview

This package provides the backend API for the knowledge graph system.

It is responsible for:
- Building and storing graph data
- Exposing nodes and edges via HTTP endpoints

---

## Running

```bash
npm install
npm run turbo:dev
```

---

## Environment Variables

```env
DATABASE_URL=postgres://USER:PASSWORD@HOST:5432/ns_world_lab
DATABASE_SCHEMA_NAME=knowledge_graph_1
```

---

## Tech Stack

- Node.js
- TypeScript
- Express or NestJS
- PostgreSQL or graph-oriented storage

---

## Responsibilities

- Graph construction logic
- Persistence layer
- API endpoints for graph retrieval

---

## Development

npm install
npm run dev

---

## API Shape (Simplified)

Nodes: id, label  
Edges: source, target, score


---

## Similarity Scoring – Jaccard

The server uses **Jaccard similarity** to compute overlap-based similarity scores
between sets (e.g. tags, neighbors, attributes).

### Definition

Jaccard similarity is defined as:

J(A, B) = |A ∩ B| / |A ∪ B|

- Range: **0.0 → 1.0**
- 0.0 means no overlap
- 1.0 means identical sets

### `minScore` Policy

There is **no intrinsic minimum score** defined by the Jaccard metric itself.

Accordingly, the server **does not enforce a hard `minScore` at computation time**.

Instead:

- All raw Jaccard scores are computed and stored
- Thresholding (if any) is applied at:
  - query time
  - ranking / sorting time
  - visualization or filtering layers

This avoids baking application-specific assumptions into the graph data.

### Practical Guidance (Non-binding)

Typical downstream heuristics (context-dependent):

- `> 0` : excludes pure non-overlap
- `≥ 0.2` : weak but meaningful overlap
- `≥ 0.4` : strong similarity
- `≥ 0.7` : near-duplicate sets

These values are **not enforced by the server** and are provided only as guidance
for consumers of the API.

### API Representation

Edges may expose similarity as:

```
score: number  // raw Jaccard similarity in [0,1]
```

No server-side pruning is performed based solely on score.

---

