# Server – Knowledge Graph API

## Overview

This package provides the backend API for the knowledge graph system.

It is responsible for:
- Building and storing graph data
- Exposing nodes and edges via HTTP endpoints

---

## Tech Stack

- Node.js
- TypeScript
- Express or NestJS
- PostgreSQL or graph-oriented storage

---

## Responsibilities

- Graph construction logic
- Persistence layer
- API endpoints for graph retrieval

---

## Development

npm install
npm run dev

---

## API Shape (Simplified)

Nodes: id, label  
Edges: source, target, score


---

## Similarity Scoring – Jaccard

The server uses **Jaccard similarity** to compute overlap-based similarity scores
between sets (e.g. tags, neighbors, attributes).

### Definition

Jaccard similarity is defined as:

J(A, B) = |A ∩ B| / |A ∪ B|

- Range: **0.0 → 1.0**
- 0.0 means no overlap
- 1.0 means identical sets

### `minScore` Policy

There is **no intrinsic minimum score** defined by the Jaccard metric itself.

Accordingly, the server **does not enforce a hard `minScore` at computation time**.

Instead:

- All raw Jaccard scores are computed and stored
- Thresholding (if any) is applied at:
  - query time
  - ranking / sorting time
  - visualization or filtering layers

This avoids baking application-specific assumptions into the graph data.

### Practical Guidance (Non-binding)

Typical downstream heuristics (context-dependent):

- `> 0` : excludes pure non-overlap
- `≥ 0.2` : weak but meaningful overlap
- `≥ 0.4` : strong similarity
- `≥ 0.7` : near-duplicate sets

These values are **not enforced by the server** and are provided only as guidance
for consumers of the API.

### API Representation

Edges may expose similarity as:

```
score: number  // raw Jaccard similarity in [0,1]
```

No server-side pruning is performed based solely on score.

---

---

## Environment

For review / portfolio usage, provide a root-level `.env.example` and keep real `.env` files local.

- Copy: `.env.example` → `.env`
- Never commit secrets (database credentials, private hosts).

Reminder:
- `VITE_*` variables are exposed to the browser and must not contain secrets.

---

## Database schema

A working schema snapshot is committed at:

- `apps/server/schema.sql`

It defines:
- `knowledge_graph_1.topic`
- `knowledge_graph_1.topic_edge`
- indexes for traversal

Apply it (example):

```bash
psql "$DATABASE_URL" -f apps/server/schema.sql
```

---

## Diagrams

Dependency diagrams are stored under `_docs/`.

Recommended stable filenames:
- `_docs/web.svg`
- `_docs/server.svg`
- `_docs/types.svg`

Embed in Markdown:

```md
![Web dependency diagram](/_docs/web.svg)
![Server dependency diagram](/_docs/server.svg)
![Types dependency diagram](/_docs/types.svg)
```
