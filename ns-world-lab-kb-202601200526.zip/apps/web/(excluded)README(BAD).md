# apps/web — Knowledge Graph UI

## Overview

Frontend application for exploring a knowledge graph.

---

## Running

```bash
npm install
npm run turbo:dev
```

---

## Environment Variables

Uses Vite-style variables.

```env
VITE_HOST=localhost
VITE_PORT=5173
VITE_GRAPH_API_HOST=localhost
VITE_GRAPH_API_PORT=3001
VITE_GRAPH_API_BASE=/api
VITE_GRAPH_API_GRAPH_ROUTER_BASE=/graph
```
