import { HasData } from "@ns-sg/types";
import { ReactNode } from "react";




export const NoData = () => <div className="text-xs text-slate-500 italic">[NO DATA]</div>