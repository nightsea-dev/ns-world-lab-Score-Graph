# Web – Score Graph Viewer

## Overview

This project is the **frontend web application** for a small knowledge-graph system.

It allows users to:
- Provide or load a set of topics
- Visualize relationships between topics as a graph
- Inspect relationships and their associated scores through interaction

The focus is on clean structure, predictable data flow, and readable implementation.

---

## Scope & Intent

- Demonstrate a clear frontend architecture
- Keep logic simple and explicit
- Avoid over-engineering
- Maintain loose coupling with the backend API

This application consumes graph data and renders it in an interactive visual form.

---

## Features

- Graph-based visualization of topics
- Dynamic rendering of nodes and edges
- Interactive node selection
- Display of:
  - Related topics
  - Relationship scores
- Lightweight and responsive UI

---

## Tech Stack

- **React**
- **TypeScript**
- Graph visualization library (Force-based / D3-based)
- Native `fetch` for API communication

---

## Project Structure

---
## Current Repository Structure (Updated)

```
apps/
  server/    # Express API, score-graph logic, persistence
  web/       # Score Graph UI and interaction layer
packages/
  types/     # Shared TypeScript contracts
_docs/       # Architecture & dependency diagrams
```

---
## Architecture Diagrams

Current architecture and dependency diagrams are maintained under `_docs/`.

---
## Environment Reference

A `.env.example` file is provided at repository root.
Runtime `.env` files are intentionally excluded from version control.

---
## Key Dependencies (Web)

- **React** — UI rendering
- **react-force-graph-2d** — Score Graph visualisation
- **RSuite** — UI component system
- **Tailwind CSS** — layout and utility styling
- **@ns-kb/types** — shared contracts with the API

The workspace is orchestrated with **Turbo**. No NestJS is used in this project.
