# Web – Score Graph Viewer 

## Overview (`apps/web`)

The web application visualises knowledge graph data and supports interactive exploration.

Primary responsibilities:
- Fetch graph nodes/edges from the API
- Render an interactive graph view
- Provide a node details surface (related topics, relationship scores)
- Apply UI-level filtering and thresholds

---

## Diagram

Place a stable diagram at `_docs/web.svg` and embed it from this README:

```md
![Web dependency diagram](/_docs/web.svg)
```

---

## Running

From repository root:

```bash
npm install
npm run dev
```

Run only the web app:

```bash
npm run dev:web
```

---

## Environment variables

The UI uses Vite-style variables.

Minimum configuration:

```env
VITE_HOST=localhost
VITE_PORT=5173

VITE_GRAPH_API_HOST=localhost
VITE_GRAPH_API_PORT=3001
VITE_GRAPH_API_BASE=/api
VITE_GRAPH_API_GRAPH_ROUTER_BASE=/graph
```

Optional UI defaults:

```env
VITE_SCORE_GRAPH_DEFAULT_MinScore=.15
VITE_SCORE_GRAPH_VIEW_CONFIG_WaitSecondsBeforeShowingTheLoader=1
VITE_SCORE_GRAPH_VIEW_CONFIG_LoadIsDisabled_GraphPayload=false
VITE_SCORE_GRAPH_VIEW_CONFIG_LoadIsDisabled_GraphNodeDetails=true
```

Notes:
- `VITE_*` variables are exposed to the browser. Do not place secrets here.
- For numeric values, prefer parsing with `||` defaults (not `??`).

---

## Tech Stack

- Node.js
- TypeScript
- PostgreSQL

---

## UX / layout rules

- Full-viewport shell (no document-level scroll)
- Only explicit inner containers scroll (`overflow-auto`, `min-h-0` patterns)
- Delay-based loaders to avoid flicker

